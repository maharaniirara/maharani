computer_amount = int(input('Total Komputer: '))
service_time = int(input('Total Komputer_2: '))
drop_off = bool(input('Total Komputer_3: '))
Pick_Up = bool(input('Total Komputer_4: '))

if (computer_amount == 1 or computer_amount == 2):
    base_fee = 500
    additional_fee = 0
elif(computer_amount >= 3 and computer_amount <= 10):
    base_fee = 100
    additional_fee = 10
elif(computer_amount > 10):
    base_fee = 500
    additional_fee = 10

if (service_time < 8 or service_time > 20):
    base_fee = base_fee*2

if(drop_off == True and Pick_Up == True ):
    Total_Base_Fee = base_fee - (base_fee*0.015)

print(Total_Base_Fee)
