m = float(input("Masukkan Nilai sisi m = "))
n = float(input("Masukkan Nilai sisi n = "))
p = float(input("Masukkan Nilai sisi p = "))

if (m==n) and (n==p) and (p==m):
    print("Segitiga sama Sisi")
elif (m==n) or (m==p) or (n==p):
    print("Segitiga sama Kaki")
elif (m*m == n*n + p*p or n*n == m*m + p*p or p*p == n*n + m*m):
    print("Segitiga Siku-siku")
elif (m or n or p <= 0) and (m >=(n+p) or (n >=m+p) or (p >=m+n)):
    print("Segitiga tidak bisa dibangun")
else:
    print("Segitiga Bebas")



